# Rabin Thapa — Data Scientist & Machine Learning Engineer

I build practical data products, AI/ML prototypes and software systems that turn data and requirements into useful outcomes.

📍 Busan, South Korea

## Featured work

- **End-to-End E-Commerce Analytics** — Python portfolio project turning raw e-commerce transactions into business decisions.
  - https://github.com/Rabin378/end-to-end-e-commerce
- **AI Skill Gap Radar** — Python project analyzing job postings, skills, salary signals, and technology trends to calculate personalized skill gaps and recommend high-value skills to learn next.
  - https://github.com/Rabin378/AI-Skill-Gap-Radar
- **Sales Data Analysis with Python**
  - https://github.com/Rabin378/sales-data-analysis-python
- **University Course Registration System**
  - https://github.com/Rabin378/University-Course-Registration-System
- **Book Management System**
  - https://github.com/Rabin378/Book-management-system
- **HTML5 Inline Elements Project**
  - https://github.com/Rabin378/html5-inline-elements-project

## Core stack

`Python` `pandas` `Matplotlib` `Machine Learning` `NLP / AI` `C++` `HTML/CSS` `Git/GitHub` `SQL`

## Work with me

I am open to freelance work involving:

- Data analysis & visualization
- Python automation
- Machine learning / AI prototypes
- Business analytics
- Data cleaning and exploratory analysis
- Small-to-medium software projects

### Contact

- Email: rv​ei9937@gmail.com
- GitHub: https://github.com/Rabin378
- LinkedIn: https://www.linkedin.com/in/ra-vei-6059b928a/
- Upwork: https://www.upwork.com/freelancers/~01292906b30c264e2c

> Portfolio site: open `index.html` from this folder.
